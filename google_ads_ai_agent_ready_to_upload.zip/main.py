import functions_framework
import datetime
import os
import requests
import json
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google.ads.googleads.client import GoogleAdsClient
from google.ads.googleads.errors import GoogleAdsException

# Load credentials from environment variables
REFRESH_TOKEN = os.environ['REFRESH_TOKEN']
CLIENT_ID = os.environ['CLIENT_ID']
CLIENT_SECRET = os.environ['CLIENT_SECRET']
DEVELOPER_TOKEN = os.environ['DEVELOPER_TOKEN']
SHEET_ID = os.environ['SHEET_ID']
HUGGINGFACE_API_KEY = os.environ['HUGGINGFACE_API_KEY']
MCC_LOGIN_CUSTOMER_ID = os.environ['MCC_LOGIN_CUSTOMER_ID']

# Hugging Face model to use
HUGGINGFACE_MODEL = "mrm8488/bert-mini-finetuned-age_news-classification"

def analyze_keyword_with_hf(keyword, website_text):
    headers = {"Authorization": f"Bearer {HUGGINGFACE_API_KEY}"}
    payload = {"inputs": f"Keyword: {keyword}\nContext: {website_text}"}
    response = requests.post(
        f"https://api-inference.huggingface.co/models/{HUGGINGFACE_MODEL}",
        headers=headers,
        json=payload
    )
    try:
        result = response.json()
        return result
    except:
        return None

@functions_framework.http
def analyze_keywords(request):
    # Load Google Ads config
    google_ads_config = {
        "developer_token": DEVELOPER_TOKEN,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "refresh_token": REFRESH_TOKEN,
        "use_proto_plus": True,
        "login_customer_id": MCC_LOGIN_CUSTOMER_ID
    }
    client = GoogleAdsClient.load_from_dict(google_ads_config)

    # Load Sheets API
    creds = Credentials.from_authorized_user_info(info={
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "refresh_token": REFRESH_TOKEN,
        "token_uri": "https://oauth2.googleapis.com/token"
    })
    service = build('sheets', 'v4', credentials=creds)
    sheet = service.spreadsheets()

    # Pull all accounts under MCC
    customer_service = client.get_service("CustomerService")
    customers = customer_service.list_accessible_customers()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    for resource_name in customers.resource_names:
        customer_id = resource_name.split("/")[-1]

        ga_service = client.get_service("GoogleAdsService")

        query = '''
        SELECT campaign.name, ad_group.name, search_term_view.search_term
        FROM search_term_view
        WHERE segments.date DURING LAST_7_DAYS
        '''

        try:
            response = ga_service.search_stream(customer_id=customer_id, query=query)
            search_terms = []

            for batch in response:
                for row in batch.results:
                    search_terms.append({
                        "Campaign": row.campaign.name,
                        "Ad Group": row.ad_group.name,
                        "Search Term": row.search_term_view.search_term,
                    })

            # Create or get the tab
            sheet_title = customer_id
            date_header = now

            try:
                sheet.batchUpdate(spreadsheetId=SHEET_ID, body={
                    "requests": [{"addSheet": {"properties": {"title": sheet_title}}}]
                }).execute()
            except:
                pass

            rows = [["Search Term", "Excluded", "Campaign Name", "Ad Group Name", "Date/Time"]]
            for item in search_terms:
                reason = analyze_keyword_with_hf(item["Search Term"], "Brand or website text here")
                excluded = "Done" if "irrelevant" in str(reason).lower() else "Not Done"
                rows.append([
                    item["Search Term"],
                    excluded,
                    item["Campaign"],
                    item["Ad Group"],
                    now
                ])

            sheet.values().append(
                spreadsheetId=SHEET_ID,
                range=f"{sheet_title}!A1",
                valueInputOption="RAW",
                body={"values": rows}
            ).execute()

        except GoogleAdsException as ex:
            print(f"Request failed for customer {customer_id}: {ex}")

    return "Done", 200